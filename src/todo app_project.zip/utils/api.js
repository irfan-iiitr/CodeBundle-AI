import axios from 'axios';

const api = axios.create({
  baseURL: 'https://your-api-endpoint.com',
});

export default api;

// Example API calls:

// Get all todos
export const getTodos = async () => {
  const response = await api.get('/todos');
  return response;
};

// Add a new todo
export const addTodo = async (todo) => {
  const response = await api.post('/todos', { text: todo });
  return response;
};

// Delete a todo
export const deleteTodo = async (id) => {
  const response = await api.delete(`/todos/${id}`);
  return response;
};

// Toggle completion of a todo
export const toggleComplete = async (id) => {
  const response = await api.put(`/todos/${id}`);
  return response;
};